
export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method tidak diizinkan." });
  }

  try {
    const { url } = req.body || {};

    if (typeof url !== "string" || url.length > 5000) {
      return res.status(400).json({ error: "URL gambar tidak valid." });
    }

    let imageURL;
    try {
      imageURL = new URL(url);
    } catch {
      return res.status(400).json({ error: "Format URL salah." });
    }

    if (!["https:", "http:"].includes(imageURL.protocol)) {
      return res.status(400).json({ error: "URL harus HTTP atau HTTPS." });
    }

    const endpoint = new URL(
      "https://api.zyvor.my.id/api/imagehd/wink-hd"
    );

    endpoint.searchParams.set("url", imageURL.href);

    const upstream = await fetch(endpoint, {
      method: "GET",
      headers: { Accept: "image/*, application/json" },
      signal: AbortSignal.timeout(55000)
    });

    if (!upstream.ok) {
      return res.status(502).json({
        error: "Layanan Ultra HD gagal.",
        status: upstream.status
      });
    }

    const contentType = upstream.headers.get("content-type") || "";

    if (contentType.startsWith("image/")) {
      const buffer = Buffer.from(await upstream.arrayBuffer());

      res.setHeader("Content-Type", contentType);
      res.setHeader("Content-Length", String(buffer.length));
      return res.status(200).send(buffer);
    }

    if (contentType.includes("application/json")) {
      const data = await upstream.json();
      return res.status(200).json(data);
    }

    return res.status(502).json({
      error: "Format respons API tidak dikenali."
    });

  } catch (error) {
    console.error("Enhance API error:", error);

    return res.status(504).json({
      error: "Server gagal menghubungi layanan Ultra HD."
    });
  }
}
